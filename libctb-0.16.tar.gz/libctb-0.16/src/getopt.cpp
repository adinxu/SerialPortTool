/////////////////////////////////////////////////////////////////////////////
// Name:        getopt.cpp
// Purpose:     simple wrapper file
// Author:      Joachim Buermann
// Id:          $Id: timer.h,v 1.1.1.1 2004/11/24 10:30:11 jb Exp $
// Copyright:   (c) 2001 Joachim Buermann
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#if defined (WIN32)
# include "win32/getopt.cpp"
#endif


